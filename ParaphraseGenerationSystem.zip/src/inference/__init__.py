"""Inference modules."""

from .generator import ParaphraseGenerator

__all__ = ["ParaphraseGenerator"]

